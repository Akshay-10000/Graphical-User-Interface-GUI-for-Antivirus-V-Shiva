﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SidePanel = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.HeaderPanel = New System.Windows.Forms.Panel()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.btnPremium = New System.Windows.Forms.Button()
        Me.btnQuickScan = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblVS = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Welcome1 = New V_Shiva.Welcome()
        Me.Full_check1 = New V_Shiva.full_check()
        Me.Scan1 = New V_Shiva.scan()
        Me.Speedup1 = New V_Shiva.speedup()
        Me.Cleanup1 = New V_Shiva.cleanup()
        Me.Close1 = New V_Shiva.close()
        Me.Tools1 = New V_Shiva.tools()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.btnTimer = New System.Windows.Forms.Timer(Me.components)
        Me.Button6 = New System.Windows.Forms.Button()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.SidePanel.SuspendLayout()
        Me.HeaderPanel.SuspendLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SidePanel
        '
        Me.SidePanel.BackColor = System.Drawing.Color.Indigo
        Me.SidePanel.Controls.Add(Me.Button2)
        Me.SidePanel.Controls.Add(Me.Button3)
        Me.SidePanel.Controls.Add(Me.Button4)
        Me.SidePanel.Controls.Add(Me.Button5)
        Me.SidePanel.Controls.Add(Me.Button1)
        Me.SidePanel.Location = New System.Drawing.Point(0, 135)
        Me.SidePanel.Name = "SidePanel"
        Me.SidePanel.Size = New System.Drawing.Size(192, 378)
        Me.SidePanel.TabIndex = 0
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button2.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.Indigo
        Me.Button2.Image = Global.V_Shiva.My.Resources.Resources.antivirus_48px
        Me.Button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button2.Location = New System.Drawing.Point(0, 115)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(192, 49)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "   VIRUS SCAN"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button3.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.Indigo
        Me.Button3.Image = Global.V_Shiva.My.Resources.Resources.exercise_48px1
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button3.Location = New System.Drawing.Point(0, 186)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(192, 46)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "SPEED UP"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button4.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.Indigo
        Me.Button4.Image = Global.V_Shiva.My.Resources.Resources.broom_48px
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button4.Location = New System.Drawing.Point(0, 255)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(192, 44)
        Me.Button4.TabIndex = 5
        Me.Button4.Text = "CLEAN UP"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button5.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.Indigo
        Me.Button5.Image = Global.V_Shiva.My.Resources.Resources.full_tool_storage_box_48px
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button5.Location = New System.Drawing.Point(0, 321)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(192, 45)
        Me.Button5.TabIndex = 6
        Me.Button5.Text = "TOOL BOX"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.Button1.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Indigo
        Me.Button1.Image = Global.V_Shiva.My.Resources.Resources.hips_48px
        Me.Button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Button1.Location = New System.Drawing.Point(0, 46)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(192, 48)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "   FULL CHECK"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'HeaderPanel
        '
        Me.HeaderPanel.BackColor = System.Drawing.Color.Silver
        Me.HeaderPanel.Controls.Add(Me.PictureBox5)
        Me.HeaderPanel.Controls.Add(Me.btnPremium)
        Me.HeaderPanel.Controls.Add(Me.btnQuickScan)
        Me.HeaderPanel.Controls.Add(Me.Panel3)
        Me.HeaderPanel.Controls.Add(Me.Label3)
        Me.HeaderPanel.Controls.Add(Me.lblVS)
        Me.HeaderPanel.Controls.Add(Me.Label2)
        Me.HeaderPanel.Location = New System.Drawing.Point(113, 26)
        Me.HeaderPanel.Name = "HeaderPanel"
        Me.HeaderPanel.Size = New System.Drawing.Size(565, 109)
        Me.HeaderPanel.TabIndex = 1
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.White
        Me.PictureBox5.Image = Global.V_Shiva.My.Resources.Resources.Corrupt_GIF_FInal_1
        Me.PictureBox5.Location = New System.Drawing.Point(437, 0)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(128, 76)
        Me.PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox5.TabIndex = 2
        Me.PictureBox5.TabStop = False
        '
        'btnPremium
        '
        Me.btnPremium.BackColor = System.Drawing.Color.Silver
        Me.btnPremium.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPremium.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPremium.ForeColor = System.Drawing.Color.Indigo
        Me.btnPremium.Location = New System.Drawing.Point(9, 40)
        Me.btnPremium.Name = "btnPremium"
        Me.btnPremium.Size = New System.Drawing.Size(190, 36)
        Me.btnPremium.TabIndex = 10
        Me.btnPremium.Text = "ACTIVATE PREMIUM"
        Me.btnPremium.UseVisualStyleBackColor = False
        '
        'btnQuickScan
        '
        Me.btnQuickScan.BackColor = System.Drawing.Color.Silver
        Me.btnQuickScan.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnQuickScan.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnQuickScan.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnQuickScan.ForeColor = System.Drawing.Color.Indigo
        Me.btnQuickScan.Location = New System.Drawing.Point(437, 78)
        Me.btnQuickScan.Name = "btnQuickScan"
        Me.btnQuickScan.Size = New System.Drawing.Size(128, 29)
        Me.btnQuickScan.TabIndex = 7
        Me.btnQuickScan.Text = "QUICK SCAN"
        Me.btnQuickScan.UseVisualStyleBackColor = False
        '
        'Panel3
        '
        Me.Panel3.Location = New System.Drawing.Point(3, 135)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(484, 378)
        Me.Panel3.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Rockwell", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Indigo
        Me.Label3.Location = New System.Drawing.Point(103, 78)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(247, 23)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Your device is protected"
        '
        'lblVS
        '
        Me.lblVS.AutoSize = True
        Me.lblVS.Font = New System.Drawing.Font("Script MT Bold", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVS.ForeColor = System.Drawing.Color.Indigo
        Me.lblVS.Location = New System.Drawing.Point(3, 2)
        Me.lblVS.Name = "lblVS"
        Me.lblVS.Size = New System.Drawing.Size(129, 42)
        Me.lblVS.TabIndex = 0
        Me.lblVS.Text = "V Shiva"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Rockwell", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Indigo
        Me.Label2.Location = New System.Drawing.Point(9, 78)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(91, 23)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "STATUS:"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.Black
        Me.Panel4.Controls.Add(Me.Welcome1)
        Me.Panel4.Controls.Add(Me.Full_check1)
        Me.Panel4.Controls.Add(Me.Scan1)
        Me.Panel4.Controls.Add(Me.Speedup1)
        Me.Panel4.Controls.Add(Me.Cleanup1)
        Me.Panel4.Controls.Add(Me.Close1)
        Me.Panel4.Controls.Add(Me.Tools1)
        Me.Panel4.Location = New System.Drawing.Point(192, 135)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(486, 375)
        Me.Panel4.TabIndex = 2
        '
        'Welcome1
        '
        Me.Welcome1.BackColor = System.Drawing.Color.Black
        Me.Welcome1.Location = New System.Drawing.Point(0, 0)
        Me.Welcome1.Name = "Welcome1"
        Me.Welcome1.Size = New System.Drawing.Size(486, 375)
        Me.Welcome1.TabIndex = 0
        '
        'Full_check1
        '
        Me.Full_check1.BackColor = System.Drawing.Color.Silver
        Me.Full_check1.Location = New System.Drawing.Point(1, 1)
        Me.Full_check1.Name = "Full_check1"
        Me.Full_check1.Size = New System.Drawing.Size(486, 375)
        Me.Full_check1.TabIndex = 7
        '
        'Scan1
        '
        Me.Scan1.BackColor = System.Drawing.Color.Silver
        Me.Scan1.Location = New System.Drawing.Point(1, 1)
        Me.Scan1.Name = "Scan1"
        Me.Scan1.Size = New System.Drawing.Size(486, 375)
        Me.Scan1.TabIndex = 8
        '
        'Speedup1
        '
        Me.Speedup1.BackColor = System.Drawing.Color.Silver
        Me.Speedup1.Location = New System.Drawing.Point(1, 1)
        Me.Speedup1.Name = "Speedup1"
        Me.Speedup1.Size = New System.Drawing.Size(486, 375)
        Me.Speedup1.TabIndex = 9
        '
        'Cleanup1
        '
        Me.Cleanup1.BackColor = System.Drawing.Color.Silver
        Me.Cleanup1.Location = New System.Drawing.Point(0, 0)
        Me.Cleanup1.Name = "Cleanup1"
        Me.Cleanup1.Size = New System.Drawing.Size(486, 375)
        Me.Cleanup1.TabIndex = 4
        '
        'Close1
        '
        Me.Close1.BackColor = System.Drawing.Color.White
        Me.Close1.Location = New System.Drawing.Point(9, 83)
        Me.Close1.Name = "Close1"
        Me.Close1.Size = New System.Drawing.Size(413, 122)
        Me.Close1.TabIndex = 5
        '
        'Tools1
        '
        Me.Tools1.BackColor = System.Drawing.Color.Silver
        Me.Tools1.Location = New System.Drawing.Point(1, 1)
        Me.Tools1.Name = "Tools1"
        Me.Tools1.Size = New System.Drawing.Size(486, 375)
        Me.Tools1.TabIndex = 10
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Monotype Corsiva", 15.75!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Indigo
        Me.Label4.Location = New System.Drawing.Point(3, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(198, 25)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "My Anti-Virus Software"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(210, 5)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(100, 18)
        Me.ProgressBar1.TabIndex = 11
        Me.ProgressBar1.Visible = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(316, 5)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(100, 18)
        Me.ProgressBar2.TabIndex = 12
        Me.ProgressBar2.Visible = False
        '
        'Timer2
        '
        '
        'btnTimer
        '
        Me.btnTimer.Enabled = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Rockwell", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(522, 0)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(29, 26)
        Me.Button6.TabIndex = 11
        Me.Button6.Text = "R"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.White
        Me.PictureBox6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox6.Image = Global.V_Shiva.My.Resources.Resources.profile_48px
        Me.PictureBox6.Location = New System.Drawing.Point(550, 0)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(32, 28)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 10
        Me.PictureBox6.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.White
        Me.PictureBox3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox3.Image = Global.V_Shiva.My.Resources.Resources.maximize_window_48px
        Me.PictureBox3.Location = New System.Drawing.Point(614, 0)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(32, 28)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 8
        Me.PictureBox3.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.White
        Me.PictureBox4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox4.Image = Global.V_Shiva.My.Resources.Resources.minimize_window_48px
        Me.PictureBox4.Location = New System.Drawing.Point(582, 0)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(32, 28)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 9
        Me.PictureBox4.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.White
        Me.PictureBox1.Image = Global.V_Shiva.My.Resources.Resources.unnamed
        Me.PictureBox1.Location = New System.Drawing.Point(0, 26)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(116, 109)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.White
        Me.PictureBox2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox2.Image = Global.V_Shiva.My.Resources.Resources.shutdown_48px
        Me.PictureBox2.Location = New System.Drawing.Point(646, 0)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(31, 28)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 7
        Me.PictureBox2.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(678, 510)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.ProgressBar2)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.HeaderPanel)
        Me.Controls.Add(Me.SidePanel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "V Shiva"
        Me.SidePanel.ResumeLayout(False)
        Me.HeaderPanel.ResumeLayout(False)
        Me.HeaderPanel.PerformLayout()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel4.ResumeLayout(False)
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents SidePanel As Panel
    Friend WithEvents lblVS As Label
    Friend WithEvents HeaderPanel As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btnQuickScan As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents btnPremium As Button
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Welcome1 As Welcome
    Friend WithEvents Cleanup1 As cleanup
    Friend WithEvents Close1 As close
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents Timer1 As Timer
    Friend WithEvents ProgressBar2 As ProgressBar
    Friend WithEvents Timer2 As Timer
    Friend WithEvents btnTimer As Timer
    Friend WithEvents Full_check1 As full_check
    Friend WithEvents Scan1 As scan
    Friend WithEvents Speedup1 As speedup
    Friend WithEvents Tools1 As tools
    Friend WithEvents Button6 As Button
End Class
