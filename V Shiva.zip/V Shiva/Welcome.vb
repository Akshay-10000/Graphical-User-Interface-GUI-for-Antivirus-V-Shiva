﻿Public Class Welcome
    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click

        quickscan.Show()

    End Sub
End Class
